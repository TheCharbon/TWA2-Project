self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "16d54fcae5002e2d2ac7341d25c87829",
    "url": "/index.html"
  },
  {
    "revision": "4cc1c95df5f931d9a6c5",
    "url": "/static/css/2.f42e59c9.chunk.css"
  },
  {
    "revision": "b73073e7a5b3aaf4ae89",
    "url": "/static/css/main.4e89baf1.chunk.css"
  },
  {
    "revision": "4cc1c95df5f931d9a6c5",
    "url": "/static/js/2.944074c3.chunk.js"
  },
  {
    "revision": "c1c8396b37f9d702000ebad3e073e630",
    "url": "/static/js/2.944074c3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b73073e7a5b3aaf4ae89",
    "url": "/static/js/main.371d09ef.chunk.js"
  },
  {
    "revision": "693d8af27c1684c7fee9",
    "url": "/static/js/runtime-main.20628b47.js"
  },
  {
    "revision": "5c0c63fb62ec323a10598d7e9de4609e",
    "url": "/static/media/memories.5c0c63fb.png"
  }
]);